# TARge24
Minu tarkvaraarenduse protsessi ainemap
